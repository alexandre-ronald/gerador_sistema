from django.conf import settings
from django.db import migrations, models
import django.db.models.deletion


class Migration(migrations.Migration):
    initial = True
    dependencies = [migrations.swappable_dependency(settings.AUTH_USER_MODEL)]
    operations = [migrations.CreateModel(
        name="AuditLog",
        fields=[
            ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
            ("timestamp", models.DateTimeField(auto_now_add=True)),
            ("action", models.CharField(choices=[("CREATE", "Criação"), ("UPDATE", "Alteração"), ("DELETE", "Exclusão")], max_length=10)),
            ("app_label", models.CharField(max_length=100)),
            ("model_name", models.CharField(max_length=100)),
            ("object_id", models.CharField(blank=True, max_length=100)),
            ("object_repr", models.TextField(blank=True)),
            ("changes", models.JSONField(blank=True, default=dict)),
            ("user", models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, to=settings.AUTH_USER_MODEL)),
        ],
        options={"ordering": ["-timestamp"]},
    )]
