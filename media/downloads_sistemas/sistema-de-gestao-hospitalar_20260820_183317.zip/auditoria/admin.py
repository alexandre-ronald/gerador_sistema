from django.contrib import admin

from .models import AuditLog


@admin.register(AuditLog)
class AuditLogAdmin(admin.ModelAdmin):
    list_display = ("timestamp", "user", "action", "app_label", "model_name", "object_id")
    list_filter = ("action", "app_label", "timestamp")
    search_fields = ("object_repr", "object_id", "model_name", "app_label")
    readonly_fields = tuple(field.name for field in AuditLog._meta.fields)
