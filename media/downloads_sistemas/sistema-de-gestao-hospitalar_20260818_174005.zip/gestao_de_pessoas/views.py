from django.contrib import messages
from django.contrib.auth.mixins import LoginRequiredMixin
from django.urls import reverse_lazy
from django.views.generic import CreateView, DeleteView, ListView, UpdateView

from .forms import FuncionarioForm
from .models import Funcionario


class FuncionarioListView(LoginRequiredMixin, ListView):
    model = Funcionario
    template_name = "gestao_de_pessoas/funcionario_list.html"
    context_object_name = "objetos"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["total_registros"] = self.get_queryset().count()
        context["titulo_pagina"] = "Funcionário"
        return context


class FuncionarioCreateView(LoginRequiredMixin, CreateView):
    model = Funcionario
    form_class = FuncionarioForm
    template_name = "gestao_de_pessoas/funcionario_form.html"
    success_url = reverse_lazy("gestao_de_pessoas:funcionario_list")

    def form_valid(self, form):
        messages.success(self.request, "Funcionário criado com sucesso!")
        return super().form_valid(form)


class FuncionarioUpdateView(LoginRequiredMixin, UpdateView):
    model = Funcionario
    form_class = FuncionarioForm
    template_name = "gestao_de_pessoas/funcionario_form.html"
    success_url = reverse_lazy("gestao_de_pessoas:funcionario_list")

    def form_valid(self, form):
        messages.success(self.request, "Funcionário atualizado!")
        return super().form_valid(form)


class FuncionarioDeleteView(LoginRequiredMixin, DeleteView):
    model = Funcionario
    template_name = "gestao_de_pessoas/funcionario_confirm_delete.html"
    success_url = reverse_lazy("gestao_de_pessoas:funcionario_list")

    def delete(self, request, *args, **kwargs):
        messages.warning(self.request, "Funcionário removido.")
        return super().delete(request, *args, **kwargs)


