from django.contrib import admin
from .models import Funcionário, Organograma


@admin.register(Funcionário)
class FuncionárioAdmin(admin.ModelAdmin):
    list_display = ['cpf', 'data de admissão', 'nome completo', ]

@admin.register(Organograma)
class OrganogramaAdmin(admin.ModelAdmin):
    list_display = ['descrição', 'sigla', ]
