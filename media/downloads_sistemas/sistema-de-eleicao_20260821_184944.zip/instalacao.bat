@echo off
SETLOCAL EnableExtensions EnableDelayedExpansion
chcp 65001 >nul
title Instalador - Sistema de Eleição

echo ====================================================================
echo   Instalador do sistema: Sistema de Eleição
echo ====================================================================
echo.

echo [1/6] Criando ambiente virtual Python...
python -m venv .venv
if %errorlevel% neq 0 (
    echo [ERRO] Falha ao criar o ambiente virtual. Verifique o Python no PATH.
    pause
    exit /b %errorlevel%
)

call .venv\Scripts\activate.bat
if %errorlevel% neq 0 (
    echo [ERRO] Falha ao ativar o ambiente virtual.
    pause
    exit /b %errorlevel%
)

echo [2/6] Atualizando o pip...
python -m pip install --upgrade pip
if %errorlevel% neq 0 (
    echo [ERRO] Falha ao atualizar o pip.
    pause
    exit /b %errorlevel%
)

if not exist requirements.txt (
    echo [ERRO] requirements.txt nao encontrado.
    pause
    exit /b 1
)

echo [3/6] Instalando dependencias do projeto...
python -m pip install -r requirements.txt
if %errorlevel% neq 0 (
    echo [ERRO] Falha ao instalar as dependencias.
    pause
    exit /b %errorlevel%
)

python manage.py check
if %errorlevel% neq 0 (
    echo [ERRO] O projeto gerado falhou no Django system check.
    pause
    exit /b %errorlevel%
)


echo.
echo ====================================================================
echo   CONFIGURACAO DO POSTGRESQL
 echo ====================================================================
echo.
echo Informe os dados do PostgreSQL instalado nesta maquina.
echo A senha nao sera exibida na tela.
echo.

set "DB_ENGINE=postgresql"
set "DB_USER=postgres"
set "DB_HOST=localhost"
set "DB_PORT=5432"
set "DB_NAME=sistema-de-eleicao_db"

set /p "DB_USER=Usuario PostgreSQL [postgres]: "
if not defined DB_USER set "DB_USER=postgres"

set /p "DB_PASSWORD=Senha do usuario %DB_USER%: "

set /p "DB_HOST=Servidor [localhost]: "
if not defined DB_HOST set "DB_HOST=localhost"

set /p "DB_PORT=Porta [5432]: "
if not defined DB_PORT set "DB_PORT=5432"

set /p "DB_NAME=Banco de dados [%DB_NAME%]: "
if not defined DB_NAME set "DB_NAME=sistema-de-eleicao_db"

python -c "from pathlib import Path; import os; Path('.env').write_text('DB_ENGINE='+os.environ['DB_ENGINE']+'\nDB_NAME='+os.environ['DB_NAME']+'\nDB_USER='+os.environ['DB_USER']+'\nDB_PASSWORD='+os.environ.get('DB_PASSWORD','')+'\nDB_HOST='+os.environ['DB_HOST']+'\nDB_PORT='+os.environ['DB_PORT']+'\n', encoding='utf-8')"
if %errorlevel% neq 0 (
    echo [ERRO] Nao foi possivel salvar a configuracao do banco em .env.
    pause
    exit /b %errorlevel%
)

echo [*] Testando acesso ao PostgreSQL e criando o banco se necessario...
python -c "import os, psycopg; from psycopg import sql; c=psycopg.connect(host=os.environ['DB_HOST'],port=os.environ['DB_PORT'],user=os.environ['DB_USER'],password=os.environ.get('DB_PASSWORD',''),dbname='postgres'); c.autocommit=True; cur=c.cursor(); cur.execute('SELECT 1 FROM pg_database WHERE datname=%s',(os.environ['DB_NAME'],)); r=cur.fetchone(); cur.execute(sql.SQL('CREATE DATABASE {}').format(sql.Identifier(os.environ['DB_NAME']))) if not r else None; c.close()"
if %errorlevel% neq 0 (
    echo.
    echo [ERRO] Nao foi possivel autenticar no PostgreSQL ou criar o banco.
    echo Verifique usuario, senha, host e porta informados.
    echo A configuracao digitada foi salva em .env para a proxima execucao.
    pause
    exit /b %errorlevel%
)


echo.
echo [4/6] Gerando migrations...
python manage.py makemigrations
if %errorlevel% neq 0 (
    echo [ERRO] Falha ao gerar migrations.
    pause
    exit /b %errorlevel%
)

echo [5/6] Aplicando migrations no banco...
python manage.py migrate
if %errorlevel% neq 0 (
    echo [ERRO] Falha ao executar migrations.
    echo.
    echo Se o PostgreSQL estiver sendo usado, confira o arquivo .env e as credenciais.
    pause
    exit /b %errorlevel%
)

echo.
echo ====================================================================
echo   CRIACAO DO USUARIO ADMINISTRADOR
 echo ====================================================================
python manage.py createsuperuser
if %errorlevel% neq 0 (
    echo [AVISO] Criacao do superusuario foi cancelada ou falhou.
)

echo.
echo [6/6] Instalacao concluida.
echo ====================================================================
echo   Sistema disponivel em: http://127.0.0.1:8000/
echo ====================================================================
echo.
pause
python manage.py runserver
