from django.urls import path

from . import views

app_name = "gestao_de_pessoas"

urlpatterns = [

    path("funcionario/", views.FuncionarioListView.as_view(), name="funcionario_list"),
    path("funcionario/novo/", views.FuncionarioCreateView.as_view(), name="funcionario_create"),
    path("funcionario/<int:pk>/editar/", views.FuncionarioUpdateView.as_view(), name="funcionario_update"),
    path("funcionario/<int:pk>/deletar/", views.FuncionarioDeleteView.as_view(), name="funcionario_delete"),

]
