from django.contrib import admin

from .models import Funcionario, Organograma


@admin.register(Funcionario)
class FuncionarioAdmin(admin.ModelAdmin):
    list_display = ["cpf", "data_de_admissao", "nome_completo", ]

@admin.register(Organograma)
class OrganogramaAdmin(admin.ModelAdmin):
    list_display = ["sigla", "descricao", ]

