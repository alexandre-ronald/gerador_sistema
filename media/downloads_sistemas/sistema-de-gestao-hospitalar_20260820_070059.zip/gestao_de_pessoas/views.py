from django.contrib import messages
from django.contrib.auth.mixins import LoginRequiredMixin
from django.urls import reverse_lazy
from django.views.generic import CreateView, DeleteView, DetailView, ListView, UpdateView

from .forms import FuncionarioForm, OrganogramaForm
from .models import Funcionario, Organograma


class FuncionarioListView(LoginRequiredMixin, ListView):
    model = Funcionario
    template_name = "gestao_de_pessoas/funcionario_list.html"
    context_object_name = "objetos"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["total_registros"] = self.get_queryset().count()
        context["titulo_pagina"] = "Funcionário"
        return context


class FuncionarioDetailView(LoginRequiredMixin, DetailView):
    model = Funcionario
    template_name = "gestao_de_pessoas/funcionario_detail.html"
    context_object_name = "objeto"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["titulo_pagina"] = "Detalhes de Funcionário"
        return context


class FuncionarioCreateView(LoginRequiredMixin, CreateView):
    model = Funcionario
    form_class = FuncionarioForm
    template_name = "gestao_de_pessoas/funcionario_form.html"
    success_url = reverse_lazy("gestao_de_pessoas:funcionario_list")

    def form_valid(self, form):
        messages.success(self.request, "Funcionário criado com sucesso!")
        return super().form_valid(form)


class FuncionarioUpdateView(LoginRequiredMixin, UpdateView):
    model = Funcionario
    form_class = FuncionarioForm
    template_name = "gestao_de_pessoas/funcionario_form.html"
    success_url = reverse_lazy("gestao_de_pessoas:funcionario_list")

    def form_valid(self, form):
        messages.success(self.request, "Funcionário atualizado!")
        return super().form_valid(form)


class FuncionarioDeleteView(LoginRequiredMixin, DeleteView):
    model = Funcionario
    template_name = "gestao_de_pessoas/funcionario_confirm_delete.html"
    success_url = reverse_lazy("gestao_de_pessoas:funcionario_list")

    def delete(self, request, *args, **kwargs):
        messages.warning(self.request, "Funcionário removido.")
        return super().delete(request, *args, **kwargs)


class OrganogramaListView(LoginRequiredMixin, ListView):
    model = Organograma
    template_name = "gestao_de_pessoas/organograma_list.html"
    context_object_name = "objetos"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["total_registros"] = self.get_queryset().count()
        context["titulo_pagina"] = "Organograma"
        return context


class OrganogramaDetailView(LoginRequiredMixin, DetailView):
    model = Organograma
    template_name = "gestao_de_pessoas/organograma_detail.html"
    context_object_name = "objeto"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["titulo_pagina"] = "Detalhes de Organograma"
        return context


class OrganogramaCreateView(LoginRequiredMixin, CreateView):
    model = Organograma
    form_class = OrganogramaForm
    template_name = "gestao_de_pessoas/organograma_form.html"
    success_url = reverse_lazy("gestao_de_pessoas:organograma_list")

    def form_valid(self, form):
        messages.success(self.request, "Organograma criado com sucesso!")
        return super().form_valid(form)


class OrganogramaUpdateView(LoginRequiredMixin, UpdateView):
    model = Organograma
    form_class = OrganogramaForm
    template_name = "gestao_de_pessoas/organograma_form.html"
    success_url = reverse_lazy("gestao_de_pessoas:organograma_list")

    def form_valid(self, form):
        messages.success(self.request, "Organograma atualizado!")
        return super().form_valid(form)


class OrganogramaDeleteView(LoginRequiredMixin, DeleteView):
    model = Organograma
    template_name = "gestao_de_pessoas/organograma_confirm_delete.html"
    success_url = reverse_lazy("gestao_de_pessoas:organograma_list")

    def delete(self, request, *args, **kwargs):
        messages.warning(self.request, "Organograma removido.")
        return super().delete(request, *args, **kwargs)


