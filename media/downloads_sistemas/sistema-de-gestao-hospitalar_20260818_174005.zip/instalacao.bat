﻿@echo off
chcp 65001 >nul
SETLOCAL EnableDelayedExpansion
title Instalador do Sistema - Sistema de Gestão Hospitalar

echo ====================================================================
echo   Configurando ambiente local para: Sistema de Gestão Hospitalar
echo ====================================================================
echo.

:: 1. Criar ambiente isolado
echo [*] Criando ambiente virtual Python (.venv)...
python -m venv .venv
if %errorlevel% neq 0 (
    echo [ERRO] Falha ao criar ambiente virtual. Verifique se o Python esta no PATH.
    pause
    exit /b %errorlevel%
)

:: 2. Ativar venv e instalar dependencias
echo [*] Ativando ambiente virtual...
call .venv\Scripts\activate.bat
if %errorlevel% neq 0 (
    echo [ERRO] Falha ao ativar o ambiente virtual.
    pause
    exit /b %errorlevel%
)

echo [*] Atualizando o gerenciador de pacotes (pip)...
python -m pip install --upgrade pip
if %errorlevel% neq 0 (
    echo [ERRO] Falha ao atualizar o pip.
    pause
    exit /b %errorlevel%
)

echo [*] Instalando dependencias do framework...
pip install django django-crispy-forms crispy-bootstrap5 pillow
if %errorlevel% neq 0 (
    echo [ERRO] Falha ao instalar dependencias do Django.
    pause
    exit /b %errorlevel%
)

:: 3. Rodar as migracoes do banco gerado
echo [*] Configurando banco de dados inicial (Migrate)...
python manage.py makemigrations
if %errorlevel% neq 0 (
    echo [ERRO] Falha ao gerar as migracoes do projeto.
    pause
    exit /b %errorlevel%
)
python manage.py migrate
if %errorlevel% neq 0 (
    echo [ERRO] Falha ao criar as tabelas no Banco de Dados.
    pause
    exit /b %errorlevel%
)

:: 4. Prompt para criar o admin do usuario final
echo.
echo ====================================================================
echo   CRIE O SEU USUARIO ADMINISTRADOR DE ACESSO
echo ====================================================================
python manage.py createsuperuser
if %errorlevel% neq 0 (
    echo [AVISO] Criacao do superusuario cancelada ou nao concluida.
)
echo.

:: 5. Iniciar a aplicacao
echo ====================================================================
echo   Tudo pronto! Seu sistema foi configurado localmente.
echo   O servidor sera iniciado em: http://127.0.0.1:8000/
echo ====================================================================
echo.
pause
python manage.py runserver
