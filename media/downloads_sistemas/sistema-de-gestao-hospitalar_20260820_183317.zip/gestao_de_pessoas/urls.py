from django.urls import path
from . import views

app_name = 'gestao_de_pessoas'

urlpatterns = [
    
    # Rotas para Funcionário
    path('funcionário/', views.FuncionárioListView.as_view(), name='funcionário_list'),
    path('funcionário/novo/', views.FuncionárioCreateView.as_view(), name='funcionário_create'),
    path('funcionário/<int:pk>/editar/', views.FuncionárioUpdateView.as_view(), name='funcionário_update'),
    path('funcionário/<int:pk>/deletar/', views.FuncionárioDeleteView.as_view(), name='funcionário_delete'),
    
    # Rotas para Organograma
    path('organograma/', views.OrganogramaListView.as_view(), name='organograma_list'),
    path('organograma/novo/', views.OrganogramaCreateView.as_view(), name='organograma_create'),
    path('organograma/<int:pk>/editar/', views.OrganogramaUpdateView.as_view(), name='organograma_update'),
    path('organograma/<int:pk>/deletar/', views.OrganogramaDeleteView.as_view(), name='organograma_delete'),
    
]