@echo off
SETLOCAL EnableExtensions
chcp 65001 >nul
title Instalador - Sistema de Eleição

echo ====================================================================
echo   Instalador do sistema: Sistema de Eleição
echo ====================================================================
echo.

python -m venv .venv
if %errorlevel% neq 0 (
    echo [ERRO] Falha ao criar o ambiente virtual.
    pause & exit /b %errorlevel%
)

call .venv\Scripts\activate.bat
if %errorlevel% neq 0 (
    echo [ERRO] Falha ao ativar o ambiente virtual.
    pause & exit /b %errorlevel%
)

python -m pip install --upgrade pip
if %errorlevel% neq 0 (
    echo [ERRO] Falha ao atualizar o pip.
    pause & exit /b %errorlevel%
)

if not exist requirements.txt (
    echo [ERRO] requirements.txt nao encontrado.
    pause & exit /b 1
)

python -m pip install -r requirements.txt
if %errorlevel% neq 0 (
    echo [ERRO] Falha ao instalar as dependencias.
    pause & exit /b %errorlevel%
)

python manage.py check
if %errorlevel% neq 0 (
    echo [ERRO] O projeto gerado falhou no Django system check.
    pause & exit /b %errorlevel%
)

python manage.py makemigrations
if %errorlevel% neq 0 (
    echo [ERRO] Falha ao gerar migrations.
    pause & exit /b %errorlevel%
)

python manage.py migrate
if %errorlevel% neq 0 (
    echo [ERRO] Falha ao executar migrations.
    pause & exit /b %errorlevel%
)

python manage.py createsuperuser
if %errorlevel% neq 0 (
    echo [AVISO] Criacao do superusuario foi cancelada ou falhou.
)

python manage.py runserver
