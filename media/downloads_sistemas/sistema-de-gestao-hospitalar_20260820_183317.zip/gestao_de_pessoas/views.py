from django.views.generic import ListView, CreateView, UpdateView, DeleteView
from django.urls import reverse_lazy
from django.contrib import messages
from django.contrib.auth.mixins import LoginRequiredMixin, PermissionRequiredMixin
from django.db.models import Q
from .models import Funcionário, Organograma
from .forms import FuncionárioForm, OrganogramaForm


# --- Views para Funcionário ---

class FuncionárioListView(LoginRequiredMixin, PermissionRequiredMixin, ListView):
    model = Funcionário
    template_name = 'gestao_de_pessoas/funcionário_list.html'
    context_object_name = 'objetos'
    paginate_by = 10
    permission_required = 'gestao_de_pessoas.view_funcionário'
    raise_exception = True

    def get_queryset(self):
        queryset = super().get_queryset()
        query = self.request.GET.get('q', '').strip()
        if query:
            search_filter = Q()
            
            
            search_filter |= Q(cpf__icontains=query)
            
            
            
            
            
            search_filter |= Q(nome completo__icontains=query)
            
            
            queryset = queryset.filter(search_filter)
        return queryset

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['total_registros'] = self.get_queryset().count()
        context['titulo_pagina'] = "Funcionários"
        context['search_query'] = self.request.GET.get('q', '').strip()
        return context


class FuncionárioCreateView(LoginRequiredMixin, PermissionRequiredMixin, CreateView):
    model = Funcionário
    form_class = FuncionárioForm
    template_name = 'gestao_de_pessoas/funcionário_form.html'
    success_url = reverse_lazy('gestao_de_pessoas:funcionário_list')
    permission_required = 'gestao_de_pessoas.add_funcionário'
    raise_exception = True

    def form_valid(self, form):
        messages.success(self.request, "Funcionário criado com sucesso!")
        return super().form_valid(form)


class FuncionárioUpdateView(LoginRequiredMixin, PermissionRequiredMixin, UpdateView):
    model = Funcionário
    form_class = FuncionárioForm
    template_name = 'gestao_de_pessoas/funcionário_form.html'
    success_url = reverse_lazy('gestao_de_pessoas:funcionário_list')
    permission_required = 'gestao_de_pessoas.change_funcionário'
    raise_exception = True

    def form_valid(self, form):
        messages.success(self.request, "Funcionário atualizado!")
        return super().form_valid(form)


class FuncionárioDeleteView(LoginRequiredMixin, PermissionRequiredMixin, DeleteView):
    model = Funcionário
    template_name = 'gestao_de_pessoas/funcionário_confirm_delete.html'
    success_url = reverse_lazy('gestao_de_pessoas:funcionário_list')
    permission_required = 'gestao_de_pessoas.delete_funcionário'
    raise_exception = True

    def delete(self, request, *args, **kwargs):
        messages.warning(self.request, "Funcionário removido.")
        return super().delete(request, *args, **kwargs)


# --- Views para Organograma ---

class OrganogramaListView(LoginRequiredMixin, PermissionRequiredMixin, ListView):
    model = Organograma
    template_name = 'gestao_de_pessoas/organograma_list.html'
    context_object_name = 'objetos'
    paginate_by = 10
    permission_required = 'gestao_de_pessoas.view_organograma'
    raise_exception = True

    def get_queryset(self):
        queryset = super().get_queryset()
        query = self.request.GET.get('q', '').strip()
        if query:
            search_filter = Q()
            
            
            search_filter |= Q(descrição__icontains=query)
            
            
            
            search_filter |= Q(sigla__icontains=query)
            
            
            queryset = queryset.filter(search_filter)
        return queryset

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['total_registros'] = self.get_queryset().count()
        context['titulo_pagina'] = "Organogramas"
        context['search_query'] = self.request.GET.get('q', '').strip()
        return context


class OrganogramaCreateView(LoginRequiredMixin, PermissionRequiredMixin, CreateView):
    model = Organograma
    form_class = OrganogramaForm
    template_name = 'gestao_de_pessoas/organograma_form.html'
    success_url = reverse_lazy('gestao_de_pessoas:organograma_list')
    permission_required = 'gestao_de_pessoas.add_organograma'
    raise_exception = True

    def form_valid(self, form):
        messages.success(self.request, "Organograma criado com sucesso!")
        return super().form_valid(form)


class OrganogramaUpdateView(LoginRequiredMixin, PermissionRequiredMixin, UpdateView):
    model = Organograma
    form_class = OrganogramaForm
    template_name = 'gestao_de_pessoas/organograma_form.html'
    success_url = reverse_lazy('gestao_de_pessoas:organograma_list')
    permission_required = 'gestao_de_pessoas.change_organograma'
    raise_exception = True

    def form_valid(self, form):
        messages.success(self.request, "Organograma atualizado!")
        return super().form_valid(form)


class OrganogramaDeleteView(LoginRequiredMixin, PermissionRequiredMixin, DeleteView):
    model = Organograma
    template_name = 'gestao_de_pessoas/organograma_confirm_delete.html'
    success_url = reverse_lazy('gestao_de_pessoas:organograma_list')
    permission_required = 'gestao_de_pessoas.delete_organograma'
    raise_exception = True

    def delete(self, request, *args, **kwargs):
        messages.warning(self.request, "Organograma removido.")
        return super().delete(request, *args, **kwargs)

