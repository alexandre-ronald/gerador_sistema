from django.conf import settings
from django.db import models


class AuditLog(models.Model):
    ACTION_CHOICES = [
        ('POST', 'Criação'),
        ('PUT', 'Atualização'),
        ('PATCH', 'Atualização parcial'),
        ('DELETE', 'Exclusão'),
    ]

    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='audit_logs',
    )
    action = models.CharField(max_length=10, choices=ACTION_CHOICES)
    path = models.CharField(max_length=500)
    method = models.CharField(max_length=10)
    status_code = models.PositiveSmallIntegerField()
    ip_address = models.GenericIPAddressField(null=True, blank=True)
    timestamp = models.DateTimeField(auto_now_add=True)
    metadata = models.JSONField(default=dict, blank=True)

    class Meta:
        ordering = ['-timestamp']
        verbose_name = 'Registro de Auditoria'
        verbose_name_plural = 'Registros de Auditoria'

    def __str__(self):
        return f'{self.timestamp:%Y-%m-%d %H:%M:%S} {self.method} {self.path}'
