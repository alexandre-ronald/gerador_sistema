from django import forms

from .models import Funcionario, Organograma


class FuncionarioForm(forms.ModelForm):
    class Meta:
        model = Funcionario
        fields = "__all__"

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field in self.fields.values():
            widget = field.widget

            if isinstance(widget, forms.CheckboxInput):
                widget.attrs.update({"class": "form-check-input"})
            elif isinstance(widget, forms.Select):
                widget.attrs.update({"class": "form-select"})
            elif isinstance(widget, forms.FileInput):
                widget.attrs.update({"class": "form-control"})
            else:
                widget.attrs.update({"class": "form-control"})

            if isinstance(field, forms.models.ModelChoiceField):
                field.empty_label = "--- Selecione uma opção ---"

            if isinstance(widget, forms.DateInput):
                widget.input_type = "date"
            elif isinstance(widget, forms.DateTimeInput):
                widget.input_type = "datetime-local"
            elif isinstance(widget, forms.TimeInput):
                widget.input_type = "time"

class OrganogramaForm(forms.ModelForm):
    class Meta:
        model = Organograma
        fields = "__all__"

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field in self.fields.values():
            widget = field.widget

            if isinstance(widget, forms.CheckboxInput):
                widget.attrs.update({"class": "form-check-input"})
            elif isinstance(widget, forms.Select):
                widget.attrs.update({"class": "form-select"})
            elif isinstance(widget, forms.FileInput):
                widget.attrs.update({"class": "form-control"})
            else:
                widget.attrs.update({"class": "form-control"})

            if isinstance(field, forms.models.ModelChoiceField):
                field.empty_label = "--- Selecione uma opção ---"

            if isinstance(widget, forms.DateInput):
                widget.input_type = "date"
            elif isinstance(widget, forms.DateTimeInput):
                widget.input_type = "datetime-local"
            elif isinstance(widget, forms.TimeInput):
                widget.input_type = "time"

