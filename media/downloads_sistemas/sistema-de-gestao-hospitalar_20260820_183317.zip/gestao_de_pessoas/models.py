from django.db import models
from django.conf import settings  # Necessário para o AUTH_USER_MODEL

# --- IMPORTS DE OUTROS APPS ---



class Funcionário(models.Model):
    
    
    cpf = models.CharField(
        max_length=255,
        
        null=False,
        blank=False,
        unique=False,
        verbose_name="Cpf"
    )
    
    
    
    data de admissão = models.DateField(
        
        
        null=False,
        blank=False,
        unique=False,
        verbose_name="Data De Admissão"
    )
    
    
    
    nome completo = models.CharField(
        max_length=255,
        
        null=False,
        blank=False,
        unique=False,
        verbose_name="Nome Completo"
    )
    
    
    
    
    # --- CAMPOS DE AUDITORIA ---
    criado_em = models.DateTimeField(auto_now_add=True, verbose_name="Criado em")
    criado_por = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True, verbose_name="Criado por")
    

    class Meta:
        verbose_name = "Funcionário"
        verbose_name_plural = "Funcionários"

    def __str__(self):
        return str(self.cpf)

class Organograma(models.Model):
    
    
    descrição = models.CharField(
        max_length=255,
        
        null=False,
        blank=False,
        unique=False,
        verbose_name="Descrição"
    )
    
    
    
    sigla = models.CharField(
        max_length=15,
        
        null=False,
        blank=False,
        unique=False,
        verbose_name="Sigla"
    )
    
    
    
    
    # --- CAMPOS DE AUDITORIA ---
    criado_em = models.DateTimeField(auto_now_add=True, verbose_name="Criado em")
    criado_por = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True, verbose_name="Criado por")
    

    class Meta:
        verbose_name = "Organograma"
        verbose_name_plural = "Organogramas"

    def __str__(self):
        return str(self.descrição)
