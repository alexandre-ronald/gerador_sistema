from django.db import models


class Candidato(models.Model):

    
    cargo = models.ForeignKey(
        "eleicao.Cargo",
        on_delete=models.CASCADE,
        null=False,
        blank=False
    )
    

    
    nome_do_candidato = models.CharField(
        max_length=255,
        null=False,
        blank=False,
        unique=False
    )
    




    class Meta:
        verbose_name = "Candidato"
        verbose_name_plural = "Candidato"

    def __str__(self):

        return str(self.cargo)


class Cargo(models.Model):

    
    descricao = models.CharField(
        max_length=255,
        null=False,
        blank=False,
        unique=False
    )
    

    
    sigla = models.CharField(
        max_length=10,
        null=False,
        blank=False,
        unique=False
    )
    




    class Meta:
        verbose_name = "Cargo"
        verbose_name_plural = "Cargo"

    def __str__(self):

        return str(self.descricao)


