from django.db import models


class Funcionario(models.Model):

    
    cpf = models.CharField(
        max_length=255,
        null=False,
        blank=False,
        unique=False
    )
    

    
    data_de_admissao = models.DateField(
        null=False,
        blank=False,
        unique=False
    )
    

    
    nome_completo = models.CharField(
        max_length=255,
        null=False,
        blank=False,
        unique=False
    )
    



    criado_em = models.DateTimeField(auto_now_add=True, verbose_name="Criado em")
    criado_por = models.ForeignKey(
        "auth.User",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="%(app_label)s_%(class)s_criados",
        verbose_name="Criado por",
    )


    class Meta:
        verbose_name = "Funcionário"
        verbose_name_plural = "Funcionário"

    def __str__(self):

        return str(self.cpf)


class Organograma(models.Model):

    
    descricao = models.CharField(
        max_length=255,
        null=False,
        blank=False,
        unique=False
    )
    

    
    sigla = models.CharField(
        max_length=15,
        null=False,
        blank=False,
        unique=False
    )
    



    criado_em = models.DateTimeField(auto_now_add=True, verbose_name="Criado em")
    criado_por = models.ForeignKey(
        "auth.User",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="%(app_label)s_%(class)s_criados",
        verbose_name="Criado por",
    )


    class Meta:
        verbose_name = "Organograma"
        verbose_name_plural = "Organograma"

    def __str__(self):

        return str(self.descricao)


