from django.contrib import messages
from django.contrib.auth.mixins import LoginRequiredMixin, PermissionRequiredMixin
from django.db.models import Q
from django.urls import reverse_lazy
from django.views.generic import CreateView, DeleteView, DetailView, ListView, UpdateView

from .forms import FuncionarioForm, OrganogramaForm
from .models import Funcionario, Organograma


class FuncionarioListView(LoginRequiredMixin, PermissionRequiredMixin, ListView):
    model = Funcionario
    template_name = "gestao_de_pessoas/funcionario_list.html"
    context_object_name = "objetos"
    permission_required = "gestao_de_pessoas.view_funcionario"
    paginate_by = 20

    def get_queryset(self):
        queryset = super().get_queryset()
        query = self.request.GET.get("q", "").strip()
        if query:
            filtros = Q()
            filtros |= Q(cpf__icontains=query)
            filtros |= Q(nome_completo__icontains=query)
            
            queryset = queryset.filter(filtros)
        return queryset

    def get_paginate_by(self, queryset):
        try:
            page_size = int(self.request.GET.get("page_size", self.paginate_by))
        except (TypeError, ValueError):
            page_size = self.paginate_by
        return max(5, min(page_size, 100))

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["total_registros"] = self.get_queryset().count()
        context["titulo_pagina"] = "Funcionário"
        context["termo_busca"] = self.request.GET.get("q", "")
        context["page_size"] = self.get_paginate_by(self.get_queryset())
        context["pode_criar"] = self.request.user.has_perm("gestao_de_pessoas.add_funcionario")
        context["pode_visualizar"] = self.request.user.has_perm("gestao_de_pessoas.view_funcionario")
        context["pode_editar"] = self.request.user.has_perm("gestao_de_pessoas.change_funcionario")
        context["pode_excluir"] = self.request.user.has_perm("gestao_de_pessoas.delete_funcionario")
        return context


class FuncionarioDetailView(LoginRequiredMixin, PermissionRequiredMixin, DetailView):
    model = Funcionario
    template_name = "gestao_de_pessoas/funcionario_detail.html"
    context_object_name = "objeto"
    permission_required = "gestao_de_pessoas.view_funcionario"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["titulo_pagina"] = "Detalhes de Funcionário"
        return context


class FuncionarioCreateView(LoginRequiredMixin, PermissionRequiredMixin, CreateView):
    model = Funcionario
    form_class = FuncionarioForm
    template_name = "gestao_de_pessoas/funcionario_form.html"
    success_url = reverse_lazy("gestao_de_pessoas:funcionario_list")
    permission_required = "gestao_de_pessoas.add_funcionario"

    def form_valid(self, form):
        messages.success(self.request, "Funcionário criado com sucesso!")
        return super().form_valid(form)


class FuncionarioUpdateView(LoginRequiredMixin, PermissionRequiredMixin, UpdateView):
    model = Funcionario
    form_class = FuncionarioForm
    template_name = "gestao_de_pessoas/funcionario_form.html"
    success_url = reverse_lazy("gestao_de_pessoas:funcionario_list")
    permission_required = "gestao_de_pessoas.change_funcionario"

    def form_valid(self, form):
        messages.success(self.request, "Funcionário atualizado!")
        return super().form_valid(form)


class FuncionarioDeleteView(LoginRequiredMixin, PermissionRequiredMixin, DeleteView):
    model = Funcionario
    template_name = "gestao_de_pessoas/funcionario_confirm_delete.html"
    success_url = reverse_lazy("gestao_de_pessoas:funcionario_list")
    permission_required = "gestao_de_pessoas.delete_funcionario"

    def delete(self, request, *args, **kwargs):
        messages.warning(self.request, "Funcionário removido.")
        return super().delete(request, *args, **kwargs)


class OrganogramaListView(LoginRequiredMixin, PermissionRequiredMixin, ListView):
    model = Organograma
    template_name = "gestao_de_pessoas/organograma_list.html"
    context_object_name = "objetos"
    permission_required = "gestao_de_pessoas.view_organograma"
    paginate_by = 20

    def get_queryset(self):
        queryset = super().get_queryset()
        query = self.request.GET.get("q", "").strip()
        if query:
            filtros = Q()
            filtros |= Q(descricao__icontains=query)
            filtros |= Q(sigla__icontains=query)
            
            queryset = queryset.filter(filtros)
        return queryset

    def get_paginate_by(self, queryset):
        try:
            page_size = int(self.request.GET.get("page_size", self.paginate_by))
        except (TypeError, ValueError):
            page_size = self.paginate_by
        return max(5, min(page_size, 100))

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["total_registros"] = self.get_queryset().count()
        context["titulo_pagina"] = "Organograma"
        context["termo_busca"] = self.request.GET.get("q", "")
        context["page_size"] = self.get_paginate_by(self.get_queryset())
        context["pode_criar"] = self.request.user.has_perm("gestao_de_pessoas.add_organograma")
        context["pode_visualizar"] = self.request.user.has_perm("gestao_de_pessoas.view_organograma")
        context["pode_editar"] = self.request.user.has_perm("gestao_de_pessoas.change_organograma")
        context["pode_excluir"] = self.request.user.has_perm("gestao_de_pessoas.delete_organograma")
        return context


class OrganogramaDetailView(LoginRequiredMixin, PermissionRequiredMixin, DetailView):
    model = Organograma
    template_name = "gestao_de_pessoas/organograma_detail.html"
    context_object_name = "objeto"
    permission_required = "gestao_de_pessoas.view_organograma"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["titulo_pagina"] = "Detalhes de Organograma"
        return context


class OrganogramaCreateView(LoginRequiredMixin, PermissionRequiredMixin, CreateView):
    model = Organograma
    form_class = OrganogramaForm
    template_name = "gestao_de_pessoas/organograma_form.html"
    success_url = reverse_lazy("gestao_de_pessoas:organograma_list")
    permission_required = "gestao_de_pessoas.add_organograma"

    def form_valid(self, form):
        messages.success(self.request, "Organograma criado com sucesso!")
        return super().form_valid(form)


class OrganogramaUpdateView(LoginRequiredMixin, PermissionRequiredMixin, UpdateView):
    model = Organograma
    form_class = OrganogramaForm
    template_name = "gestao_de_pessoas/organograma_form.html"
    success_url = reverse_lazy("gestao_de_pessoas:organograma_list")
    permission_required = "gestao_de_pessoas.change_organograma"

    def form_valid(self, form):
        messages.success(self.request, "Organograma atualizado!")
        return super().form_valid(form)


class OrganogramaDeleteView(LoginRequiredMixin, PermissionRequiredMixin, DeleteView):
    model = Organograma
    template_name = "gestao_de_pessoas/organograma_confirm_delete.html"
    success_url = reverse_lazy("gestao_de_pessoas:organograma_list")
    permission_required = "gestao_de_pessoas.delete_organograma"

    def delete(self, request, *args, **kwargs):
        messages.warning(self.request, "Organograma removido.")
        return super().delete(request, *args, **kwargs)


