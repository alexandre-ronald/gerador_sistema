from django.db import models


class Funcionario(models.Model):

    
    cpf = models.CharField(
        max_length=255,
        null=False,
        blank=False,
        unique=False
    )
    

    
    data_de_admissao = models.DateField(
        null=False,
        blank=False,
        unique=False
    )
    

    
    nome_completo = models.CharField(
        max_length=255,
        null=False,
        blank=False,
        unique=False
    )
    




    class Meta:
        verbose_name = "Funcionário"
        verbose_name_plural = "Funcionário"

    def __str__(self):

        return str(self.cpf)


class Organograma(models.Model):

    
    sigla = models.CharField(
        max_length=15,
        null=False,
        blank=False,
        unique=False
    )
    

    
    descricao = models.CharField(
        max_length=255,
        null=False,
        blank=False,
        unique=False
    )
    




    class Meta:
        verbose_name = "Organograma"
        verbose_name_plural = "Organograma"

    def __str__(self):

        return str(self.sigla)


