from django.utils.deprecation import MiddlewareMixin

from .models import AuditLog


class AuditMiddleware(MiddlewareMixin):
    METHODS = {'POST', 'PUT', 'PATCH', 'DELETE'}

    def process_response(self, request, response):
        if request.method in self.METHODS and not request.path.startswith('/static/'):
            user = request.user if getattr(request, 'user', None) and request.user.is_authenticated else None
            forwarded = request.META.get('HTTP_X_FORWARDED_FOR', '')
            ip_address = forwarded.split(',')[0].strip() if forwarded else request.META.get('REMOTE_ADDR')
            AuditLog.objects.create(
                user=user,
                action=request.method,
                path=request.path[:500],
                method=request.method,
                status_code=response.status_code,
                ip_address=ip_address,
                metadata={'query': dict(request.GET)},
            )
        return response
