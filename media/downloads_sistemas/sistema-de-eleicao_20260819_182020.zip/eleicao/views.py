from django.contrib import messages
from django.contrib.auth.mixins import LoginRequiredMixin
from django.db.models import Q
from django.urls import reverse_lazy
from django.views.generic import CreateView, DeleteView, DetailView, ListView, UpdateView

from .forms import CandidatoForm, CargoForm
from .models import Candidato, Cargo


class CandidatoListView(LoginRequiredMixin, ListView):
    model = Candidato
    template_name = "eleicao/candidato_list.html"
    context_object_name = "objetos"
    paginate_by = 10

    def get_queryset(self):
        queryset = super().get_queryset()
        query = self.request.GET.get("q", "").strip()
        if query:
            search = Q()
            for field in self.model._meta.fields:
                if field.get_internal_type() in {"CharField", "TextField", "EmailField", "URLField"}:
                    search |= Q(**{f"{field.name}__icontains": query})
            if search:
                queryset = queryset.filter(search)
        for field in self.model._meta.fields:
            value = self.request.GET.get(field.name, "").strip()
            if value:
                queryset = queryset.filter(**{f"{field.name}__icontains": value})
        return queryset

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["total_registros"] = self.get_queryset().count()
        context["titulo_pagina"] = "Candidato"
        context["filtros"] = {key: value for key, value in self.request.GET.items() if key != "page" and value}
        return context


class CandidatoDetailView(LoginRequiredMixin, DetailView):
    model = Candidato
    template_name = "eleicao/candidato_detail.html"
    context_object_name = "objeto"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["titulo_pagina"] = "Detalhes de Candidato"
        return context


class CandidatoCreateView(LoginRequiredMixin, CreateView):
    model = Candidato
    form_class = CandidatoForm
    template_name = "eleicao/candidato_form.html"
    success_url = reverse_lazy("eleicao:candidato_list")

    def form_valid(self, form):
        messages.success(self.request, "Candidato criado com sucesso!")
        return super().form_valid(form)


class CandidatoUpdateView(LoginRequiredMixin, UpdateView):
    model = Candidato
    form_class = CandidatoForm
    template_name = "eleicao/candidato_form.html"
    success_url = reverse_lazy("eleicao:candidato_list")

    def form_valid(self, form):
        messages.success(self.request, "Candidato atualizado!")
        return super().form_valid(form)


class CandidatoDeleteView(LoginRequiredMixin, DeleteView):
    model = Candidato
    template_name = "eleicao/candidato_confirm_delete.html"
    success_url = reverse_lazy("eleicao:candidato_list")

    def delete(self, request, *args, **kwargs):
        messages.warning(self.request, "Candidato removido.")
        return super().delete(request, *args, **kwargs)


class CargoListView(LoginRequiredMixin, ListView):
    model = Cargo
    template_name = "eleicao/cargo_list.html"
    context_object_name = "objetos"
    paginate_by = 10

    def get_queryset(self):
        queryset = super().get_queryset()
        query = self.request.GET.get("q", "").strip()
        if query:
            search = Q()
            for field in self.model._meta.fields:
                if field.get_internal_type() in {"CharField", "TextField", "EmailField", "URLField"}:
                    search |= Q(**{f"{field.name}__icontains": query})
            if search:
                queryset = queryset.filter(search)
        for field in self.model._meta.fields:
            value = self.request.GET.get(field.name, "").strip()
            if value:
                queryset = queryset.filter(**{f"{field.name}__icontains": value})
        return queryset

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["total_registros"] = self.get_queryset().count()
        context["titulo_pagina"] = "Cargo"
        context["filtros"] = {key: value for key, value in self.request.GET.items() if key != "page" and value}
        return context


class CargoDetailView(LoginRequiredMixin, DetailView):
    model = Cargo
    template_name = "eleicao/cargo_detail.html"
    context_object_name = "objeto"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["titulo_pagina"] = "Detalhes de Cargo"
        return context


class CargoCreateView(LoginRequiredMixin, CreateView):
    model = Cargo
    form_class = CargoForm
    template_name = "eleicao/cargo_form.html"
    success_url = reverse_lazy("eleicao:cargo_list")

    def form_valid(self, form):
        messages.success(self.request, "Cargo criado com sucesso!")
        return super().form_valid(form)


class CargoUpdateView(LoginRequiredMixin, UpdateView):
    model = Cargo
    form_class = CargoForm
    template_name = "eleicao/cargo_form.html"
    success_url = reverse_lazy("eleicao:cargo_list")

    def form_valid(self, form):
        messages.success(self.request, "Cargo atualizado!")
        return super().form_valid(form)


class CargoDeleteView(LoginRequiredMixin, DeleteView):
    model = Cargo
    template_name = "eleicao/cargo_confirm_delete.html"
    success_url = reverse_lazy("eleicao:cargo_list")

    def delete(self, request, *args, **kwargs):
        messages.warning(self.request, "Cargo removido.")
        return super().delete(request, *args, **kwargs)


