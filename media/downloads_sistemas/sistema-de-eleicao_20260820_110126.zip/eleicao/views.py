from django.contrib import messages
from django.contrib.auth.mixins import LoginRequiredMixin, PermissionRequiredMixin
from django.db.models import Q
from django.urls import reverse_lazy
from django.views.generic import CreateView, DeleteView, DetailView, ListView, UpdateView

from .forms import CandidatoForm, CargoForm
from .models import Candidato, Cargo


class CandidatoListView(LoginRequiredMixin, PermissionRequiredMixin, ListView):
    model = Candidato
    template_name = "eleicao/candidato_list.html"
    context_object_name = "objetos"
    permission_required = "eleicao.view_candidato"
    paginate_by = 20

    def get_queryset(self):
        queryset = super().get_queryset()
        query = self.request.GET.get("q", "").strip()
        if query:
            filtros = Q()
            filtros |= Q(nome_do_candidato__icontains=query)
            
            queryset = queryset.filter(filtros)
        return queryset

    def get_paginate_by(self, queryset):
        try:
            page_size = int(self.request.GET.get("page_size", self.paginate_by))
        except (TypeError, ValueError):
            page_size = self.paginate_by
        return max(5, min(page_size, 100))

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["total_registros"] = self.get_queryset().count()
        context["titulo_pagina"] = "Candidato"
        context["termo_busca"] = self.request.GET.get("q", "")
        context["page_size"] = self.get_paginate_by(self.get_queryset())
        context["pode_criar"] = self.request.user.has_perm("eleicao.add_candidato")
        context["pode_visualizar"] = self.request.user.has_perm("eleicao.view_candidato")
        context["pode_editar"] = self.request.user.has_perm("eleicao.change_candidato")
        context["pode_excluir"] = self.request.user.has_perm("eleicao.delete_candidato")
        return context


class CandidatoDetailView(LoginRequiredMixin, PermissionRequiredMixin, DetailView):
    model = Candidato
    template_name = "eleicao/candidato_detail.html"
    context_object_name = "objeto"
    permission_required = "eleicao.view_candidato"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["titulo_pagina"] = "Detalhes de Candidato"
        return context


class CandidatoCreateView(LoginRequiredMixin, PermissionRequiredMixin, CreateView):
    model = Candidato
    form_class = CandidatoForm
    template_name = "eleicao/candidato_form.html"
    success_url = reverse_lazy("eleicao:candidato_list")
    permission_required = "eleicao.add_candidato"

    def form_valid(self, form):
        messages.success(self.request, "Candidato criado com sucesso!")
        return super().form_valid(form)


class CandidatoUpdateView(LoginRequiredMixin, PermissionRequiredMixin, UpdateView):
    model = Candidato
    form_class = CandidatoForm
    template_name = "eleicao/candidato_form.html"
    success_url = reverse_lazy("eleicao:candidato_list")
    permission_required = "eleicao.change_candidato"

    def form_valid(self, form):
        messages.success(self.request, "Candidato atualizado!")
        return super().form_valid(form)


class CandidatoDeleteView(LoginRequiredMixin, PermissionRequiredMixin, DeleteView):
    model = Candidato
    template_name = "eleicao/candidato_confirm_delete.html"
    success_url = reverse_lazy("eleicao:candidato_list")
    permission_required = "eleicao.delete_candidato"

    def delete(self, request, *args, **kwargs):
        messages.warning(self.request, "Candidato removido.")
        return super().delete(request, *args, **kwargs)


class CargoListView(LoginRequiredMixin, PermissionRequiredMixin, ListView):
    model = Cargo
    template_name = "eleicao/cargo_list.html"
    context_object_name = "objetos"
    permission_required = "eleicao.view_cargo"
    paginate_by = 20

    def get_queryset(self):
        queryset = super().get_queryset()
        query = self.request.GET.get("q", "").strip()
        if query:
            filtros = Q()
            filtros |= Q(descricao__icontains=query)
            filtros |= Q(sigla__icontains=query)
            
            queryset = queryset.filter(filtros)
        return queryset

    def get_paginate_by(self, queryset):
        try:
            page_size = int(self.request.GET.get("page_size", self.paginate_by))
        except (TypeError, ValueError):
            page_size = self.paginate_by
        return max(5, min(page_size, 100))

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["total_registros"] = self.get_queryset().count()
        context["titulo_pagina"] = "Cargo"
        context["termo_busca"] = self.request.GET.get("q", "")
        context["page_size"] = self.get_paginate_by(self.get_queryset())
        context["pode_criar"] = self.request.user.has_perm("eleicao.add_cargo")
        context["pode_visualizar"] = self.request.user.has_perm("eleicao.view_cargo")
        context["pode_editar"] = self.request.user.has_perm("eleicao.change_cargo")
        context["pode_excluir"] = self.request.user.has_perm("eleicao.delete_cargo")
        return context


class CargoDetailView(LoginRequiredMixin, PermissionRequiredMixin, DetailView):
    model = Cargo
    template_name = "eleicao/cargo_detail.html"
    context_object_name = "objeto"
    permission_required = "eleicao.view_cargo"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["titulo_pagina"] = "Detalhes de Cargo"
        return context


class CargoCreateView(LoginRequiredMixin, PermissionRequiredMixin, CreateView):
    model = Cargo
    form_class = CargoForm
    template_name = "eleicao/cargo_form.html"
    success_url = reverse_lazy("eleicao:cargo_list")
    permission_required = "eleicao.add_cargo"

    def form_valid(self, form):
        messages.success(self.request, "Cargo criado com sucesso!")
        return super().form_valid(form)


class CargoUpdateView(LoginRequiredMixin, PermissionRequiredMixin, UpdateView):
    model = Cargo
    form_class = CargoForm
    template_name = "eleicao/cargo_form.html"
    success_url = reverse_lazy("eleicao:cargo_list")
    permission_required = "eleicao.change_cargo"

    def form_valid(self, form):
        messages.success(self.request, "Cargo atualizado!")
        return super().form_valid(form)


class CargoDeleteView(LoginRequiredMixin, PermissionRequiredMixin, DeleteView):
    model = Cargo
    template_name = "eleicao/cargo_confirm_delete.html"
    success_url = reverse_lazy("eleicao:cargo_list")
    permission_required = "eleicao.delete_cargo"

    def delete(self, request, *args, **kwargs):
        messages.warning(self.request, "Cargo removido.")
        return super().delete(request, *args, **kwargs)


