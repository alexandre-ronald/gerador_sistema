from django.db import models
from django.conf import settings  # Necessário para o AUTH_USER_MODEL

# --- IMPORTS DE OUTROS APPS ---



class Candidato(models.Model):
    
    
    cargo = models.ForeignKey(
        'eleicao.Cargo',
        on_delete=models.CASCADE,
        null=False,
        blank=False,
        
        verbose_name="Cargo"
    )
    
    
    
    nome do candidato = models.CharField(
        max_length=255,
        
        null=False,
        blank=False,
        unique=False,
        verbose_name="Nome Do Candidato"
    )
    
    
    
    

    class Meta:
        verbose_name = "Candidato"
        verbose_name_plural = "Candidatos"

    def __str__(self):
        return str(self.cargo)

class Cargo(models.Model):
    
    
    descricao = models.CharField(
        max_length=255,
        
        null=False,
        blank=False,
        unique=False,
        verbose_name="Descricao"
    )
    
    
    
    sigla = models.CharField(
        max_length=10,
        
        null=False,
        blank=False,
        unique=False,
        verbose_name="Sigla"
    )
    
    
    
    

    class Meta:
        verbose_name = "Cargo"
        verbose_name_plural = "Cargos"

    def __str__(self):
        return str(self.descricao)
