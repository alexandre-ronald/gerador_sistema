from django.contrib import admin
from django.urls import include, path
from django.views.generic import TemplateView
from django.contrib.auth.decorators import login_required

urlpatterns = [
    path("admin/", admin.site.urls),
    path("accounts/", include("django.contrib.auth.urls")),
    path(
        "",
        login_required(TemplateView.as_view(template_name="index.html")),
        name="index",
    ),

    path(
        "gestao-de-pessoas/",
        include("gestao_de_pessoas.urls"),
    ),

]
